import {getFunc} from "../utils/getFn";
import post_play from "../../definitions/post_play";

export default getFunc(
  "post play",
  "team_post_play",
  "post_play_location",
  post_play,
  "team"
);
