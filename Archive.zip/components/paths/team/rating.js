import {getFunc} from "../utils/getFn";
import rating from "../../definitions/rating";

export default getFunc("rating", "team_rating", "offensive_and_defensive_ratings", rating, "team")