import {getFunc} from "../utils/getFn";
import rating from "../../definitions/rating";

export default getFunc("rating", "team_rating", "ratings", rating, "team")