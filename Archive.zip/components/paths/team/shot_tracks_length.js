import shot_tracks from "../../definitions/shot_tracks";
import getFunc from "../utils/getFn";

export default getFunc(
  "shot tracks length",
  "shot_tracks_length",
  "shot_tracks_length",
  shot_tracks,
  "team"
);
