import {getFunc} from "../utils/getFn";
import style from "../../definitions/style";

export default getFunc(
  "Style Comps",
  "team_style_comps",
  "style",
  style,
  "team"
);
