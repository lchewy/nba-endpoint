import {getFunc} from "../utils/getFn";
import both_3_players from "../../definitions/top_3";

export default getFunc(
  "both 3 players",
  "game_both_3_players",
  "shot_makers",
  both_3_players,
  "game",
  "both 3 shot makers"
);
