import team from "./team";
import player from "./player";
import game from "./game";
const paths = { ...team, ...player, ...game };
export default paths;
