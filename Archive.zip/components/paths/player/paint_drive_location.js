import {getFunc} from "../utils/getFn";
import paint_drive_location from "../../definitions/paint_drive_location";

export default getFunc(
  "paint drive location player",
  "paint_drive_location_player",
  "paint_drive_location",
  paint_drive_location,
  "player"
);
