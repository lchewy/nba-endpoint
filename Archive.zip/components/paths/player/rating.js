import {getFunc} from "../utils/getFn";
import rating from "../../definitions/rating";

export default getFunc("rating", "player_rating", "offensive_and_defensive_ratings", rating, "player");
