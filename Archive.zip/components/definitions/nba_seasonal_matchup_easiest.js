const str = { type: "string" };

export default {
  type: "object",
  properties: {
    easiest_matchup_offense_1: str,
    easiest_matchup_offense_2: str,
    easiest_matchup_offense_3: str,
    card_image: str
  }
};
