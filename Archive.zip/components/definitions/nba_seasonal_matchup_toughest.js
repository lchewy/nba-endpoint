const str = { type: "string" };

export default {
  type: "object",
  properties: {
    toughest_matchup_offense_1: str,
    toughest_matchup_offense_2: str,
    toughest_matchup_offense_3: str,
    card_image: str
  }
};
