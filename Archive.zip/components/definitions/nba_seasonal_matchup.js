const str = { type: "string" };

export const easiest_matchup_offense = {
  // type: "array",
  // items: {
  type: "object",
  properties: {
    easiest_matchup_offense_1: str,
    easiest_matchup_offense_2: str,
    easiest_matchup_offense_3: str,
    player_ID: str,
    graphic_title: str
    // card_image: str
    // }
  }
};

export const toughest_matchup_offense = {
  // type: "array",
  // items: {
  type: "object",
  properties: {
    toughest_matchup_offense_1: str,
    toughest_matchup_offense_2: str,
    toughest_matchup_offense_3: str,
    player_ID: str,
    graphic_title: str
    // card_image: str
    // }
  }
};

export const easiest_matchup_defense = {
  // type: "array",
  // items: {
  type: "object",
  properties: {
    easiest_matchup_defense_1: str,
    easiest_matchup_defense_2: str,
    easiest_matchup_defense_3: str,
    player_ID: str,
    graphic_title: str,
    // card_image: str
    // }
  }
};

export const toughest_matchup_defense = {
  // type: "array",
  // items: {
  type: "object",
  properties: {
    toughest_matchup_defense_1: str,
    toughest_matchup_defense_2: str,
    toughest_matchup_defense_3: str,
    player_ID: str,
    graphic_title: str,
    // card_image: str
    // }
  }
};
